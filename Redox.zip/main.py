import os
#os.system('pip install -U jishaku')
from asyncore import loop
import datetime
import random
import time
import math
import discord
from core.Astroz import Astroz
import colorama
from colorama import Fore
import asyncio, json
import jishaku, cogs
from discord.ext import commands, tasks
from utils.Tools import *
from utils.config import OWNER_IDS, No_Prefix
import traceback
from discord import app_commands
from discord.ext.commands import Context
from discord import Spotify
from discord import Embed

web = "webhook url"

os.environ["JISHAKU_NO_DM_TRACEBACK"] = "True"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"

client = Astroz()
tree = client.tree
clr = 0x41eeee
bot = client

async def VisionX_stats():
  while True:
    servers = len(client.guilds)
    users = sum(g.member_count for g in client.guilds
                if g.member_count != None)
    sv_ch = client.get_channel(1173252399364841544)
    users_ch = client.get_channel(1173252428213268540)
    await asyncio.sleep(600)
    await sv_ch.edit(name="『Servers : {} 』".format(servers))
    await users_ch.edit(name="『Users : {} 』".format(users))




##################################
@client.listen("on_member_join")
async def oner_join(member):
    data = getautorole(member.guild.id)
    bot_roles = data["botautoroles"]
    human_roles = data["humanautoroles"]
    reason = f"{client.user.name} | Autorole"

    if member.bot:
        if bot_roles:
            for role_id in bot_roles:
                role = member.guild.get_role(int(role_id))
                if role:
                    try:
                        await member.add_roles(role, reason=reason)
                    except discord.Forbidden:
                        print(f"Bot doesn't have permissions to assign role {role.name}")
                    except discord.HTTPException:
                        print(f"Failed to assign role {role.name} to {member.display_name}")
                else:
                    print(f"Role with ID {role_id} not found.")
        else:
            pass
    else:
        if human_roles:
            for role_id in human_roles:
                role = member.guild.get_role(int(role_id))
                if role:
                    try:
                        await member.add_roles(role, reason=reason)
                    except discord.Forbidden:
                        print(f"Bot doesn't have permissions to assign role {role.name}")
                    except discord.HTTPException:
                        print(f"Failed to assign role {role.name} to {member.display_name}")
                else:
                    print(f"Role with ID {role_id} not found.")
        else:
            pass
##################################

@client.event
async def on_command_completion(context: Context) -> None:
    await client.wait_until_ready()
    full_command_name = context.command.qualified_name
    split = full_command_name.split("\n")
    executed_command = str(split[0])
    hacker = discord.SyncWebhook.from_url(web)
    if not context.message.content.startswith("$"):
        pcmd = f"`{context.message.content}`"
    else:
        pcmd = f"`{context.message.content}`"
    if context.guild is not None:
        try:
            
            embed = discord.Embed(color=0x2f3136)
            embed.set_author(
                name=
                f"Executed {executed_command} Command By : {context.author}",
                icon_url=f"{context.author.avatar}")
            embed.set_thumbnail(url=f"{context.author.avatar}")
            embed.add_field(
                name="Command Name :",
                value=f"{executed_command}",
                inline=False)
            embed.add_field(
                name="Command Content :",
                value="{}".format(pcmd),
                inline=False)
            embed.add_field(
                name="Command Executed By :",
                value=
                f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
                inline=False)
            embed.add_field(
                name="Command Executed In :",
                value=
                f"{context.guild.name}  | ID: [{context.guild.id}](https://discord.com/users/{context.author.id})",
                inline=False)
            embed.add_field(
                name=
                "Command Executed In Channel :",
                value=
                f"{context.channel.name}  | ID: [{context.channel.id}](https://discord.com/channel/{context.channel.id})",
                inline=False)
            embed.set_footer(text=f"Thank you for choosing  {client.user.name}",
                             icon_url=client.user.display_avatar.url)
            hacker.send(embed=embed)
        except:
            print('LOL')
    else:
        try:

            embed1 = discord.Embed(color=0x2f3136)
            embed1.set_author(
                name=
                f"Executed {executed_command} Command By : {context.author}",
                icon_url=f"{context.author.avatar}")
            embed1.set_thumbnail(url=f"{context.author.avatar}")
            embed1.add_field(
                name="Command Name :",
                value=f"{executed_command}",
                inline=False)
            embed1.add_field(
                name="Command Executed By :",
                value=
                f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
                inline=False)
            embed1.set_footer(text=f"Thank you for choosing  {client.user.name}",
                              icon_url=client.user.display_avatar.url)
            hacker.send(embed=embed1)
        except:
            print("Lowl")    
            
@client.event
async def on_ready(): 
  print (Fore.RED+ "MADE FOR AMAN ONLY")
  print(Fore.RED + "Loaded & I Online!")
  print(Fore.BLUE + f"Logged in as: {client.user}")
  print(Fore.MAGENTA + f"Connected to: {len(client.guilds)} guilds")
  print(Fore.YELLOW + f"Connected to: {len(client.users)} users")
 # synced_commands = await client.tree.sync()

 # print(f'Synced {len(synced_commands)} commands')

#  await client.loop.create_task(VisionX_stats())            




tkn =""
async def main():
  async with client:
    os.system("clear")
    await client.load_extension("cogs")
    await client.load_extension("jishaku")
    await client.start(tkn)


if __name__ == "__main__":
  asyncio.run(main())
